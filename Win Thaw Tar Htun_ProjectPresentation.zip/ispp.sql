-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2025 at 01:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ispp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(30) NOT NULL,
  `password` int(30) NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `password`, `username`) VALUES
(1, 123456, 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) NOT NULL,
  `cname` varchar(150) NOT NULL,
  `deleted_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `cname`, `deleted_at`) VALUES
(1, 'Drink', NULL),
(2, 'Snack', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cusid` int(40) NOT NULL,
  `cusname` varchar(50) NOT NULL,
  `cuspassword` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cusid`, `cusname`, `cuspassword`) VALUES
(1, 'Nora', 1233);

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `deliveryid` int(30) NOT NULL,
  `paymentconfirmid` int(30) NOT NULL,
  `deliverytypeid` int(30) NOT NULL,
  `deliveryaddress` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`deliveryid`, `paymentconfirmid`, `deliverytypeid`, `deliveryaddress`) VALUES
(1, 1, 1, '-'),
(2, 1, 4, '35879 Adobe');

-- --------------------------------------------------------

--
-- Table structure for table `deliverytype`
--

CREATE TABLE `deliverytype` (
  `deliverytypeid` int(30) NOT NULL,
  `deliverytype` varchar(30) NOT NULL,
  `deliveryfee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deliverytype`
--

INSERT INTO `deliverytype` (`deliverytypeid`, `deliverytype`, `deliveryfee`) VALUES
(1, 'Pickup', 0),
(3, 'Standard', 10),
(4, 'Express', 20),
(5, 'Overnight', 30);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(40) NOT NULL,
  `shoppingcartid` int(40) NOT NULL,
  `cusid` int(40) NOT NULL,
  `paymentid` int(40) NOT NULL,
  `orderdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `shoppingcartid`, `cusid`, `paymentid`, `orderdate`) VALUES
(1, 1, 1, 2, '2025-11-27'),
(2, 2, 1, 3, '2025-11-27'),
(3, 3, 1, 4, '2025-11-27'),
(4, 4, 1, 5, '2025-11-27'),
(5, 5, 1, 6, '2025-11-27'),
(6, 6, 1, 7, '2025-11-27'),
(7, 7, 1, 8, '2025-11-27'),
(8, 8, 1, 9, '2025-11-27'),
(9, 13, 1, 14, '2025-11-28'),
(10, 14, 1, 15, '2025-11-28'),
(11, 15, 1, 16, '2025-11-28'),
(12, 16, 1, 17, '2025-11-29'),
(13, 17, 1, 18, '2025-12-04'),
(14, 18, 1, 19, '2025-12-04'),
(15, 19, 1, 20, '2025-12-04'),
(16, 20, 1, 21, '2025-12-07'),
(17, 21, 1, 22, '2025-12-07'),
(18, 22, 1, 23, '2025-12-07'),
(19, 23, 1, 24, '2025-12-08');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `orderdetailid` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`orderdetailid`, `orderid`, `pid`, `qty`, `price`, `total`) VALUES
(1, 3, 4, 1, 12.00, 12.00),
(2, 4, 5, 1, 20.00, 20.00),
(3, 4, 2, 1, 21.00, 21.00),
(4, 5, 3, 1, 16.00, 16.00),
(5, 5, 6, 1, 20.00, 20.00),
(6, 6, 3, 1, 16.00, 16.00),
(7, 7, 1, 1, 20.00, 20.00),
(8, 7, 2, 1, 21.00, 21.00),
(9, 9, 1, 1, 20.00, 20.00),
(10, 10, 2, 1, 21.00, 21.00),
(11, 11, 1, 1, 20.00, 20.00),
(12, 12, 1, 1, 20.00, 20.00),
(13, 13, 1, 1, 20.00, 20.00),
(14, 14, 2, 1, 21.00, 21.00),
(15, 15, 1, 1, 20.00, 20.00),
(16, 16, 3, 1, 16.00, 16.00),
(19, 19, 1, 1, 20.00, 20.00);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentid` int(30) NOT NULL,
  `paymentamount` int(30) NOT NULL,
  `paymentdate` date NOT NULL,
  `paymenttype` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`paymentid`, `paymentamount`, `paymentdate`, `paymenttype`) VALUES
(1, 10, '2025-11-06', 'cash'),
(5, 41, '2025-11-27', 'cash'),
(6, 36, '2025-11-27', 'cash'),
(7, 16, '2025-11-27', 'debit'),
(8, 51, '2025-11-27', 'debit'),
(9, 10, '2025-11-27', 'debit'),
(10, 20, '2025-11-28', 'cash'),
(11, 20, '2025-11-28', 'cash'),
(12, 20, '2025-11-28', 'cash'),
(13, 20, '2025-11-28', 'cash'),
(14, 20, '2025-11-28', 'cash'),
(15, 21, '2025-11-28', 'cash'),
(16, 20, '2025-11-28', 'cash'),
(17, 40, '2025-11-29', 'credit'),
(18, 20, '2025-12-04', 'debit'),
(19, 21, '2025-12-04', 'debit'),
(20, 20, '2025-12-04', 'debit'),
(21, 46, '2025-12-07', 'cash'),
(22, 21, '2025-12-07', 'cash'),
(23, 41, '2025-12-07', 'debit'),
(24, 30, '2025-12-08', 'debit');

-- --------------------------------------------------------

--
-- Table structure for table `paymentconfirm`
--

CREATE TABLE `paymentconfirm` (
  `paymentconfirmid` int(30) NOT NULL,
  `adminid` int(30) NOT NULL,
  `paymentid` int(30) NOT NULL,
  `paymentconfirmdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentconfirm`
--

INSERT INTO `paymentconfirm` (`paymentconfirmid`, `adminid`, `paymentid`, `paymentconfirmdate`) VALUES
(1, 1, 1, '2025-11-06');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Pid` int(11) NOT NULL,
  `Pname` varchar(100) NOT NULL,
  `Pprice` int(11) NOT NULL,
  `Pimage` varchar(50) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `deleted_at` date DEFAULT NULL,
  `staffid` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Pid`, `Pname`, `Pprice`, `Pimage`, `sub_category_id`, `deleted_at`, `staffid`) VALUES
(1, 'Beef Burger', 20, 'beefburger.jpg', 2, NULL, 141),
(2, 'Fish Burger', 21, 'fishburger.jpg', 2, NULL, 141),
(3, 'Chicken Burger', 16, 'chickenburger.jpg', 2, NULL, 141),
(4, 'Egg Burger', 12, 'eggburger.jpg', 2, NULL, 141),
(5, 'Matcha Bubble Tea', 20, 'matchabobatea.jpg', 1, NULL, 111),
(6, 'Milk Shake', 20, 'milkshake.jpg', 5, NULL, 111),
(7, 'Strawberry Milk Tea', 20, 'strawberrymilktea.jpg', 1, NULL, 111),
(8, 'Cheese Fries', 10, 'Potatoe.jpg.jpg', 3, NULL, 111);

-- --------------------------------------------------------

--
-- Table structure for table `productdetail`
--

CREATE TABLE `productdetail` (
  `productdetailid` int(30) NOT NULL,
  `productid` int(30) NOT NULL,
  `sizeid` int(30) NOT NULL,
  `shoppingcartid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productdetail`
--

INSERT INTO `productdetail` (`productdetailid`, `productid`, `sizeid`, `shoppingcartid`) VALUES
(1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shoppingcart`
--

CREATE TABLE `shoppingcart` (
  `shoppingcartid` int(100) NOT NULL,
  `orderid` int(40) NOT NULL,
  `cartqty` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shoppingcart`
--

INSERT INTO `shoppingcart` (`shoppingcartid`, `orderid`, `cartqty`) VALUES
(1, 1, 22),
(2, 2, 22),
(3, 3, 22),
(4, 4, 41),
(5, 5, 36),
(6, 6, 16),
(7, 7, 51),
(8, 8, 10),
(9, 0, 20),
(10, 0, 20),
(11, 0, 20),
(12, 0, 20),
(13, 9, 20),
(14, 10, 21),
(15, 11, 20),
(16, 12, 40),
(17, 13, 20),
(18, 14, 21),
(19, 15, 20),
(20, 16, 46),
(21, 17, 21),
(22, 18, 41),
(23, 19, 30);

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `sizeid` int(30) NOT NULL,
  `size` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`sizeid`, `size`) VALUES
(1, 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffid` int(30) NOT NULL,
  `spassword` varchar(30) NOT NULL,
  `susername` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffid`, `spassword`, `susername`) VALUES
(111, 'winthawtarhtun', 'win'),
(112, 'noranora', 'noraa'),
(141, '22June2005', 'june'),
(143, '123456', 'noenoe');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `scid` int(11) NOT NULL,
  `scname` varchar(150) NOT NULL,
  `deleted_at` date DEFAULT NULL,
  `scimage` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`scid`, `scname`, `deleted_at`, `scimage`, `category_id`) VALUES
(1, 'Juice', NULL, 'juice.jpg', 1),
(2, 'Burger', NULL, 'burger.jpeg', 2),
(3, 'Fries', NULL, 'popcornchicken.jpeg', 2),
(4, 'Milktea', NULL, 'strawberrymilktea.jpg', 1),
(5, 'Milkshake', NULL, 'milkshake.jpg', 1),
(10, 'Potatoe Fries', NULL, 'Potatoe.jpg.jpg', 2),
(11, 'Juice', '2025-11-27', '', 1),
(12, 'Juice', '2025-11-27', '', 1),
(13, 'Test', '2025-11-27', 'juice.jpg', 1),
(14, 'Fries', NULL, 'juice.jpg', 1),
(15, 'Juice', '2025-11-27', 'juice.jpg', 1),
(16, 'Fries', '2025-11-27', 'juice.jpg', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cusid`);

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`deliveryid`),
  ADD KEY `paymentconfirmid` (`paymentconfirmid`),
  ADD KEY `deliverytypeid` (`deliverytypeid`);

--
-- Indexes for table `deliverytype`
--
ALTER TABLE `deliverytype`
  ADD PRIMARY KEY (`deliverytypeid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `cusid` (`cusid`),
  ADD KEY `paymentid` (`paymentid`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`orderdetailid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentid`);

--
-- Indexes for table `paymentconfirm`
--
ALTER TABLE `paymentconfirm`
  ADD PRIMARY KEY (`paymentconfirmid`),
  ADD KEY `adminid` (`adminid`),
  ADD KEY `paymentid` (`paymentid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Pid`),
  ADD KEY `sub_category_id` (`sub_category_id`),
  ADD KEY `staffid` (`staffid`);

--
-- Indexes for table `productdetail`
--
ALTER TABLE `productdetail`
  ADD PRIMARY KEY (`productdetailid`),
  ADD KEY `productid` (`productid`),
  ADD KEY `sizeid` (`sizeid`),
  ADD KEY `shoppingcartid` (`shoppingcartid`);

--
-- Indexes for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  ADD PRIMARY KEY (`shoppingcartid`);

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`sizeid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staffid`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`scid`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cusid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `deliveryid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `deliverytype`
--
ALTER TABLE `deliverytype`
  MODIFY `deliverytypeid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `orderdetailid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `paymentconfirm`
--
ALTER TABLE `paymentconfirm`
  MODIFY `paymentconfirmid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `productdetail`
--
ALTER TABLE `productdetail`
  MODIFY `productdetailid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shoppingcart`
--
ALTER TABLE `shoppingcart`
  MODIFY `shoppingcartid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `sizeid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staffid` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `scid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `orders` (`orderid`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `product` (`Pid`);

--
-- Constraints for table `paymentconfirm`
--
ALTER TABLE `paymentconfirm`
  ADD CONSTRAINT `paymentconfirm_ibfk_1` FOREIGN KEY (`adminid`) REFERENCES `admin` (`adminid`),
  ADD CONSTRAINT `paymentconfirm_ibfk_2` FOREIGN KEY (`paymentid`) REFERENCES `payment` (`paymentid`);

--
-- Constraints for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD CONSTRAINT `sub_categories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`cid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
