<?php include 'header.php'; ?>

<body class="homepage">
 
  <section class="herosection" 
  style="background-image: url('images/homepage.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;"> 
  <div class="herooverlay"></div> 
  <div class="herocontent"> 
    <h1 class="herotitle">The Alley Snacks & Drinks</h1> 
    <a href="snack.php" class="herobutton">SHOP PARTY</a> 
  </div> 
</section>

<div class="container">
    <div class="col-12 mt-5 mb-3">
        <h4 class="text-center">Our Products</h4>
    </div>
    <div class="row mb-4">
     <div class="col-md-4 col-12">
        <div class="card" style="height: 435px;">
          <img class="card-img-top hoteimg" src="images/burger.jpeg" alt="Card image cap" style="height: 100%;" >
          <div class="card-body text-center">
            <p class="card-text">Burger</p>
          </div>
        </div>
    </div>
    <div class="col-md-4 col-12">
        <div class="card">
          <img class="card-img-top hoteimg" src="images/milkshake.jpg" alt="Card image cap" >
          <div class="card-body text-center">
            <p class="card-text">Drink</p>
          </div>
        </div>
    </div>
    <div class="col-md-4 col-12">
        <div class="card">
          <img class="card-img-top hoteimg" src="images/Potatoe.jpg.jpg" alt="Card image cap">
          <div class="card-body text-center">
            <p class="card-text">Potato Fries</p>
          </div>
        </div>
    </div>
    </div>
</div>

  <?php include('footer.php');?>

</body>

</html>