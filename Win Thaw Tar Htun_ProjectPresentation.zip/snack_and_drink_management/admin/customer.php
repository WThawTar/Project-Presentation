<?php
include("../connect.php");

$cusid = "";
$cusname = "";
$cuspassword = "";
$btnname = "Insert";

// Handle update form pre-fill
if (isset($_GET['cusid'])) {
    $cusid = $_GET['cusid'];
    $cusname = $_GET['cusname'];
    $cuspassword = $_GET['cuspassword'];
    $btnname = "Update";
}

// Handle insert or update
if (isset($_POST['btn_customer'])) {
    $cusname_post = $_POST['cusname'];
    $cuspassword_post = $_POST['cuspassword'];

    if ($_POST['btn_customer'] == "Insert") {
        $sql_insert = "INSERT INTO customer (cusname, cuspassword) VALUES ('$cusname_post', '$cuspassword_post')";
        $con->query($sql_insert);
    } else { // Update
        $cusid = $_POST['cusid'];
        $sql_update = "UPDATE customer SET cusname='$cusname_post', cuspassword='$cuspassword_post' WHERE cusid=$cusid";
        $con->query($sql_update);
    }

    // Reset form
    $cusid = "";
    $cusname = "";
    $cuspassword = "";
    $btnname = "Insert";
}

// Handle delete
if (isset($_GET['dcusid'])) {
    $dcusid = $_GET['dcusid'];
    $sql_delete = "DELETE FROM customer WHERE cusid=$dcusid";
    $con->query($sql_delete);
}
?>

<h3 class="text-center mb-4">Manage Customer</h3>

<!-- Customer Form -->
<div class="card p-4 mb-5 shadow-sm" style="max-width: 500px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="cusid" value="<?php echo $cusid; ?>">

        <div class="mb-3">
            <label for="cusname" class="form-label">Customer Name</label>
            <input type="text" name="cusname" id="cusname" required class="form-control" value="<?php echo $cusname; ?>">
        </div>

        <div class="mb-3">
            <label for="cuspassword" class="form-label">Customer Password</label>
            <input type="text" name="cuspassword" id="cuspassword" required class="form-control" value="<?php echo $cuspassword; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_customer" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<!-- Customer Table -->
<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Customer Id</th>
                <th>Customer Name</th>
               
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM customer";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['cusid']}</td>
                            <td>{$row['cusname']}</td>
                           
                            <td>
                                <a href='index.php?cusid={$row['cusid']}&cusname={$row['cusname']}&cuspassword={$row['cuspassword']}' class='btn btn-outline-primary'>Update</a>
                            </td>
                            <td>
                                <a href='index.php?dcusid={$row['cusid']}' onclick=\"return confirm('Are you sure you want to delete this customer?')\" class='btn btn-outline-danger'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No customers found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
