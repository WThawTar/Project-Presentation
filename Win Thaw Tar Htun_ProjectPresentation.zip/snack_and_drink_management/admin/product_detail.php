<?php
include("../connect.php");

$productdetailid = "";
$productid = "";
$sizeid = "";
$shoppingcartid = "";
$btnname = "Insert";

if(isset($_GET['productdetailid'])){
    $productdetailid = $_GET['productdetailid'];
    $productid = $_GET['productid'];
    $sizeid = $_GET['sizeid'];
    $shoppingcartid = $_GET['shoppingcartid'];
    $btnname = "Update";
}

if(isset($_POST['btn_productdetail'])){
    $productdetailid_post = $_POST['productdetailid'];
    $productid_post = $_POST['productid'];
    $sizeid_post = $_POST['sizeid'];
    $shoppingcartid_post = $_POST['shoppingcartid'];

    if($_POST['btn_productdetail'] == "Insert"){
        if($productid_post != "" && $sizeid_post != "" && $shoppingcartid_post != ""){
            $sql = "INSERT INTO productdetail (productid, sizeid, shoppingcartid) 
                    VALUES ($productid_post, $sizeid_post, $shoppingcartid_post)";
            $con->query($sql);
            echo "<h4 class='text-success'>Product Detail inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    if($_POST['btn_productdetail'] == "Update"){
        if($productid_post != "" && $sizeid_post != "" && $shoppingcartid_post != ""){
            $sql = "UPDATE productdetail SET productid=$productid_post, sizeid=$sizeid_post, 
                    shoppingcartid=$shoppingcartid_post WHERE productdetailid=$productdetailid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Product Detail updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $productdetailid = "";
    $productid = "";
    $sizeid = "";
    $shoppingcartid = "";
    $btnname = "Insert";
}

if(isset($_GET['dproductdetailid'])){
    $dproductdetailid = $_GET['dproductdetailid'];
    $sql = "DELETE FROM productdetail WHERE productdetailid=$dproductdetailid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Product Details</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 700px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="productdetailid" value="<?php echo $productdetailid; ?>">

        <div class="mb-3">
            <label for="productid" class="form-label">Product</label>
            <select name="productid" id="productid" required class="form-select">
                <option value="">-- Select Product --</option>
                <?php
                $product_sql = "SELECT pid, pname FROM product";
                $product_query = mysqli_query($con, $product_sql);
                while($p = mysqli_fetch_assoc($product_query)){
                    $selected = ($p['pid'] == $productid) ? "selected" : "";
                    echo "<option value='{$p['pid']}' $selected>{$p['pname']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="sizeid" class="form-label">Size</label>
            <select name="sizeid" id="sizeid" required class="form-select">
                <option value="">-- Select Size --</option>
                <?php
                $size_sql = "SELECT sizeid, size FROM size";
                $size_query = mysqli_query($con, $size_sql);
                while($s = mysqli_fetch_assoc($size_query)){
                    $selected = ($s['sizeid'] == $sizeid) ? "selected" : "";
                    echo "<option value='{$s['sizeid']}' $selected>{$s['size']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="shoppingcartid" class="form-label">Shopping Cart</label>
            <select name="shoppingcartid" id="shoppingcartid" required class="form-select">
                <option value="">-- Select Shopping Cart --</option>
                <?php
                $cart_sql = "SELECT sc.shoppingcartid, o.orderid, sc.cartqty FROM shoppingcart sc
                             LEFT JOIN orders o ON sc.orderid = o.orderid";
                $cart_query = mysqli_query($con, $cart_sql);
                while($sc = mysqli_fetch_assoc($cart_query)){
                    $display = "CartID: ".$sc['shoppingcartid']." | OrderID: ".$sc['orderid']." | Qty: ".$sc['cartqty'];
                    $selected = ($sc['shoppingcartid'] == $shoppingcartid) ? "selected" : "";
                    echo "<option value='{$sc['shoppingcartid']}' $selected>$display</option>";
                }
                ?>
            </select>
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_productdetail" class="btn btn-dark px-4">
        </div>
    </form>
</div>



<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Product Detail ID</th>
                <th>Product</th>
                <th>Size</th>
                <th>Shopping Cart</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT pd.productdetailid, pd.productid, pd.sizeid, pd.shoppingcartid,
                           p.pname, s.size, sc.cartqty, o.orderid
                    FROM productdetail pd
                    LEFT JOIN product p ON pd.productid = p.pid
                    LEFT JOIN size s ON pd.sizeid = s.sizeid
                    LEFT JOIN shoppingcart sc ON pd.shoppingcartid = sc.shoppingcartid
                    LEFT JOIN orders o ON sc.orderid = o.orderid";

            if(isset($_GET['search_data']) && $_GET['search_data'] != ""){
                $search = mysqli_real_escape_string($con, $_GET['search_data']);
                $sql .= " WHERE pd.productdetailid LIKE '%$search%' OR p.pname LIKE '%$search%'";
            }

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    $cart_info = "CartID: ".$row['shoppingcartid']." | OrderID: ".$row['orderid']." | Qty: ".$row['cartqty'];
                    echo "
                    <tr>
                        <td>{$row['productdetailid']}</td>
                        <td>{$row['pname']}</td>
                        <td>{$row['size']}</td>
                        <td>$cart_info</td>
                        <td>
                            <a href='?productdetailid={$row['productdetailid']}&productid={$row['productid']}&sizeid={$row['sizeid']}&shoppingcartid={$row['shoppingcartid']}' class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dproductdetailid={$row['productdetailid']}' class='btn btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this product detail?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>No product details found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
