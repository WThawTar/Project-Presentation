<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>



  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3 col-lg-2 sidebar p-0">
        <div class="d-flex p-3 user">
          <i class="bi bi-person-circle fs-3 me-3"></i>
          <div class="d-lg-inline-block d-none">
            <span class="name mb-1 fw-bold">John Doe</span>
            <p class="text-success mb-0">
              <span class="badge bg-success">Active</span>
            </p>
          </div>
        </div>
        
        <div class="p-3">
          <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link active" href="#">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
              </a>
            </li>
                       
            <li class="nav-item mt-3">
              <small class="text-muted ps-3">MENU MANAGEMENT</small>
            </li>
          
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=admin.php">
                <i class="bi bi-tags me-2"></i> Admin
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="index.php?page=categories.php">
                <i class="bi bi-tags me-2"></i> Categories
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=customer.php">
                <i class="bi bi-tags me-2"></i> Customer
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=delivery.php">
                <i class="bi bi-tags me-2"></i> Delivery
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=delivery_type.php">
                <i class="bi bi-tags me-2"></i> Delivery Type
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=order.php">
                <i class="bi bi-tags me-2"></i> Order
              </a>
            </li>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=order_details.php">
                <i class="bi bi-tags me-2"></i> Order Details
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=payment.php">
                <i class="bi bi-tags me-2"></i> Payment
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=payment_confirm.php">
                <i class="bi bi-tags me-2"></i> Payment Confirm
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=product.php">
                <i class="bi bi-tags me-2"></i> Product
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=product_detail.php">
                <i class="bi bi-tags me-2"></i> Product Detail
              </a>
            </li>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=shoppingcart.php">
                <i class="bi bi-tags me-2"></i> Shopping Cart
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=size.php">
                <i class="bi bi-tags me-2"></i> Size
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php?page=staff.php">
                <i class="bi bi-tags me-2"></i> Staff
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="index.php?page=subcategories.php">
                <i class="bi bi-tags me-2"></i> Sub Categories
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="index.php?page=report.php">
                <i class="bi bi-tags me-2"></i> Report
              </a>
            </li>
            
            <li class="nav-item mt-4">
              <a class="nav-link text-danger" href="../index.php">
                <i class="bi bi-box-arrow-right me-2"></i> Logout
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div class="col-md-9 col-lg-10 px-0">
        <header class="admin-header py-3 px-4">
          <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Dashboard Overview</h5>
            <div class="d-flex align-items-center">
              <span class="me-3">Admin User</span>
             
            </div>
          </div>
        </header>
        
        
        <div class="p-4">
          <div class="alert alert-info ms-4">
            Welcome back!
          </div>
          


    
   <div class="admin-right">
      <?php  
          if(isset($_GET['page'])){
              include $_GET['page'];
              $_SESSION["page"]=$_GET["page"];
          }
          else if (isset($_SESSION['page'])){
              include $_SESSION['page'];
          }
      ?>
  </div>
        
</body>
</html>




