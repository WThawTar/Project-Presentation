<?php
include("../connect.php");

$scid = "";
$scname = "";
$scimage = "";
$category_id = "";
$btnname = "Insert";

$allowed_types = ['image/png','image/jpeg','image/gif'];
$max_size = 2*1024*1024; 

if(isset($_GET['scid'])){
    $scid = $_GET['scid'];
    $scname = $_GET['scname'];
    $category_id = $_GET['category_id'];
    $scimage = $_GET['scimage'];
    $btnname = "Update";
}

if(isset($_POST['btn_subcategory'])){
    $scid_post = $_POST['scid'];
    $scname_post = trim($_POST['scname']);
    $category_id_post = $_POST['category_id'];
    $filename = "";

    if(isset($_FILES['scimage']['name']) && $_FILES['scimage']['name'] != ""){
        $filename = $_FILES['scimage']['name'];
        $type = $_FILES['scimage']['type'];
        $size = $_FILES['scimage']['size'];
        $loc = "../images/$filename";

        if(in_array($type, $allowed_types) && $size <= $max_size){
            move_uploaded_file($_FILES['scimage']['tmp_name'], $loc);
        } else {
            echo '<h2 class="text-danger">Wrong File Type or File too large!</h2>';
            $filename = $_POST['old_scimage']; 
        }
    } else {
        $filename = $_POST['old_scimage'] ?? "";
    }

    if($_POST['btn_subcategory'] == "Insert"){
        if($scname_post != "" && $category_id_post != "" && $filename != ""){
            $sql = "INSERT INTO sub_categories (scname, scimage, category_id) 
                    VALUES ('$scname_post', '$filename', $category_id_post)";
            $con->query($sql);
            echo "<h4 class='text-success'>Sub Category inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields and upload an image.</h4>";
        }
    }

    if($_POST['btn_subcategory'] == "Update"){
        if($scname_post != "" && $category_id_post != ""){
            $sql = "UPDATE sub_categories SET scname='$scname_post', scimage='$filename', category_id=$category_id_post 
                    WHERE scid=$scid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Sub Category updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $scid = "";
    $scname = "";
    $scimage = "";
    $category_id = "";
    $btnname = "Insert";
}

if(isset($_GET['dscid'])){
    $dscid = $_GET['dscid'];
    $deleted_at = date('Y-m-d H:i:s');
    $sql = "UPDATE sub_categories SET deleted_at='$deleted_at' WHERE scid=$dscid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Sub Categories</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 600px; margin:auto;">
    <form action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="scid" value="<?php echo $scid; ?>">
        <input type="hidden" name="old_scimage" value="<?php echo $scimage; ?>">

        <div class="mb-3">
            <label for="scname" class="form-label">Sub Category Name</label>
            <input type="text" name="scname" id="scname" required class="form-control" value="<?php echo $scname; ?>">
        </div>

        <div class="mb-3">
            <label for="category_id" class="form-label">Parent Category</label>
            <select name="category_id" id="category_id" required class="form-select">
                <option value="">-- Select Category --</option>
                <?php
                $cat_sql = "SELECT * FROM categories WHERE deleted_at IS NULL";
                $cat_query = mysqli_query($con, $cat_sql);
                while($cat = mysqli_fetch_assoc($cat_query)){
                    $selected = ($cat['cid'] == $category_id) ? "selected" : "";
                    echo "<option value='{$cat['cid']}' $selected>{$cat['cname']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="scimage" class="form-label">Sub Category Image</label>
            <input type="file" name="scimage" id="scimage" class="form-control">
            <?php if($scimage != ""): ?>
                <small>Current Image: <img src="../images/<?php echo $scimage; ?>" width="80"></small>
            <?php endif; ?>
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_subcategory" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Sub Category ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Image</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT sc.*, c.cname FROM sub_categories sc 
                    LEFT JOIN categories c ON sc.category_id = c.cid 
                    WHERE sc.deleted_at IS NULL";

            if(isset($_GET['search_data']) && $_GET['search_data'] != ""){
                $search = mysqli_real_escape_string($con, $_GET['search_data']);
                $sql .= " AND scname LIKE '%$search%'";
            }

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    echo "
                    <tr>
                        <td>{$row['scid']}</td>
                        <td>{$row['scname']}</td>
                        <td>{$row['cname']}</td>
                        <td><img src='../images/{$row['scimage']}' width='100'></td>
                        <td>
                            <a href='?scid={$row['scid']}&scname={$row['scname']}&category_id={$row['category_id']}&scimage={$row['scimage']}' 
                               class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dscid={$row['scid']}' class='btn btn-outline-danger' 
                               onclick=\"return confirm('Are you sure you want to delete this sub category?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>No sub categories found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
