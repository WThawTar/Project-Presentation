<?php
include("../connect.php");

$paymentconfirmid = "";
$adminid = "";
$paymentid = "";
$paymentconfirmdate = "";
$btnname = "Insert";

if(isset($_GET['paymentconfirmid'])){
    $paymentconfirmid = $_GET['paymentconfirmid'];
    $adminid = $_GET['adminid'];
    $paymentid = $_GET['paymentid'];
    $paymentconfirmdate = $_GET['paymentconfirmdate'];
    $btnname = "Update";
}

if(isset($_POST['btn_paymentconfirm'])){
    $paymentconfirmid_post = $_POST['paymentconfirmid'];
    $adminid_post = $_POST['adminid'];
    $paymentid_post = $_POST['paymentid'];
    $paymentconfirmdate_post = $_POST['paymentconfirmdate'];

    if($_POST['btn_paymentconfirm'] == "Insert"){
        if($adminid_post != "" && $paymentid_post != "" && $paymentconfirmdate_post != ""){
            $sql = "INSERT INTO paymentconfirm (adminid, paymentid, paymentconfirmdate) 
                    VALUES ('$adminid_post', '$paymentid_post', '$paymentconfirmdate_post')";
            $con->query($sql);
            echo "<h4 class='text-success'>Payment Confirm inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    if($_POST['btn_paymentconfirm'] == "Update"){
        if($adminid_post != "" && $paymentid_post != "" && $paymentconfirmdate_post != ""){
            $sql = "UPDATE paymentconfirm SET adminid='$adminid_post', paymentid='$paymentid_post', 
                    paymentconfirmdate='$paymentconfirmdate_post' WHERE paymentconfirmid=$paymentconfirmid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Payment Confirm updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $paymentconfirmid = "";
    $adminid = "";
    $paymentid = "";
    $paymentconfirmdate = "";
    $btnname = "Insert";
}

if(isset($_GET['dpaymentconfirmid'])){
    $dpaymentconfirmid = $_GET['dpaymentconfirmid'];
    $sql = "DELETE FROM paymentconfirm WHERE paymentconfirmid=$dpaymentconfirmid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Payment Confirms</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 600px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="paymentconfirmid" value="<?php echo $paymentconfirmid; ?>">

        <div class="mb-3">
            <label for="adminid" class="form-label">Admin</label>
            <select name="adminid" id="adminid" required class="form-select">
                <option value="">-- Select Admin --</option>
                <?php
                $admin_sql = "SELECT * FROM admin";
                $admin_query = mysqli_query($con, $admin_sql);
                while($admin = mysqli_fetch_assoc($admin_query)){
                    $selected = ($admin['adminid'] == $adminid) ? "selected" : "";
                    echo "<option value='{$admin['adminid']}' $selected>{$admin['username']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="paymentid" class="form-label">Payment</label>
            <select name="paymentid" id="paymentid" required class="form-select">
                <option value="">-- Select Payment --</option>
                <?php
                $payment_sql = "SELECT * FROM payment";
                $payment_query = mysqli_query($con, $payment_sql);
                while($payment = mysqli_fetch_assoc($payment_query)){
                    $display = $payment['paymentamount'] . " - " . $payment['paymenttype'];
                    $selected = ($payment['paymentid'] == $paymentid) ? "selected" : "";
                    echo "<option value='{$payment['paymentid']}' $selected>$display</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="paymentconfirmdate" class="form-label">Payment Confirm Date</label>
            <input type="date" name="paymentconfirmdate" id="paymentconfirmdate" required class="form-control" value="<?php echo $paymentconfirmdate; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_paymentconfirm" class="btn btn-dark px-4">
        </div>
    </form>
</div>


<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Payment Confirm ID</th>
                <th>Admin Username</th>
                <th>Payment Amount - Type</th>
                <th>Confirm Date</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT pc.paymentconfirmid, pc.adminid, pc.paymentid, a.username, 
                           p.paymentamount, p.paymenttype, pc.paymentconfirmdate
                    FROM paymentconfirm pc
                    LEFT JOIN admin a ON pc.adminid = a.adminid
                    LEFT JOIN payment p ON pc.paymentid = p.paymentid";

            if(isset($_GET['search_data']) && $_GET['search_data'] != ""){
                $search = mysqli_real_escape_string($con, $_GET['search_data']);
                $sql .= " WHERE pc.paymentconfirmid LIKE '%$search%'";
            }

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    echo "
                    <tr>
                        <td>{$row['paymentconfirmid']}</td>
                        <td>{$row['username']}</td>
                        <td>{$row['paymentamount']} - {$row['paymenttype']}</td>
                        <td>{$row['paymentconfirmdate']}</td>
                        <td>
                            <a href='?paymentconfirmid={$row['paymentconfirmid']}&adminid={$row['adminid']}&paymentid={$row['paymentid']}&paymentconfirmdate={$row['paymentconfirmdate']}' 
                               class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dpaymentconfirmid={$row['paymentconfirmid']}' class='btn btn-outline-danger' 
                               onclick=\"return confirm('Are you sure you want to delete this payment confirm?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>No payment confirms found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
