<?php
include("../connect.php");

$sizeid = "";
$size = "";
$btnname = "Insert";

if (isset($_GET['sizeid'])) {
    $sizeid = $_GET['sizeid'];
    $size = $_GET['size'];
    $btnname = "Update";
}

if (isset($_POST['btn_size'])) {
    $size_post = $_POST['size'];

    if ($_POST['btn_size'] == "Insert") {
        $sql_insert = "INSERT INTO size (size) VALUES ('$size_post')";
        $con->query($sql_insert);
    } else { 
        $sizeid = $_POST['sizeid'];
        $sql_update = "UPDATE size SET size='$size_post' WHERE sizeid=$sizeid";
        $con->query($sql_update);
    }

    $sizeid = "";
    $size = "";
    $btnname = "Insert";
}

if (isset($_GET['dsizeid'])) {
    $dsizeid = $_GET['dsizeid'];
    $sql_delete = "DELETE FROM size WHERE sizeid=$dsizeid";
    $con->query($sql_delete);
}
?>

<h3 class="text-center mb-4">Manage Size</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 500px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="sizeid" value="<?php echo $sizeid; ?>">

        <div class="mb-3">
            <label for="size" class="form-label">Size</label>
            <input type="text" name="size" id="size" required class="form-control" value="<?php echo $size; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_size" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Size Id</th>
                <th>Size</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM size";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['sizeid']}</td>
                            <td>{$row['size']}</td>
                            <td>
                                <a href='index.php?sizeid={$row['sizeid']}&size={$row['size']}' class='btn btn-outline-primary'>Update</a>
                            </td>
                            <td>
                                <a href='index.php?dsizeid={$row['sizeid']}' onclick=\"return confirm('Are you sure you want to delete this size?')\" class='btn btn-outline-danger'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No sizes found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
