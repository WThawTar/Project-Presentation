<?php
include("../connect.php");

$Pid = "";
$Pname = "";
$Pprice = "";
$Pimage = "";
$sub_category_id = "";
$staffid = "";
$btnname = "Insert";

$allowed_types = ['image/png','image/jpeg','image/gif'];
$max_size = 2*1024*1024; 

if(isset($_GET['Pid'])){
    $Pid = $_GET['Pid'];
    $Pname = $_GET['Pname'];
    $Pprice = $_GET['Pprice'];
    $sub_category_id = $_GET['sub_category_id'];
    $staffid = $_GET['staffid'];
    $Pimage = $_GET['Pimage'];
    $btnname = "Update";
}

if(isset($_POST['btn_product'])){
    $Pid_post = $_POST['Pid'];
    $Pname_post = trim($_POST['Pname']);
    $Pprice_post = $_POST['Pprice'];
    $sub_category_id_post = $_POST['sub_category_id'];
    $staffid_post = $_POST['staffid'];
    $filename = "";

    if(isset($_FILES['Pimage']['name']) && $_FILES['Pimage']['name'] != ""){
        $filename = $_FILES['Pimage']['name'];
        $type = $_FILES['Pimage']['type'];
        $size = $_FILES['Pimage']['size'];
        $loc = "../images/$filename";

        if(in_array($type, $allowed_types) && $size <= $max_size){
            move_uploaded_file($_FILES['Pimage']['tmp_name'], $loc);
        } else {
            echo '<h2 class="text-danger">Wrong File Type or File too large!</h2>';
            $filename = $_POST['old_Pimage'] ?? "";
        }
    } else {
        $filename = $_POST['old_Pimage'] ?? "";
    }

    if($_POST['btn_product'] == "Insert"){
        if($Pname_post != "" && $Pprice_post != "" && $sub_category_id_post != "" && $staffid_post != "" && $filename != ""){
            $sql = "INSERT INTO product (Pname, Pprice, Pimage, sub_category_id, staffid) 
                    VALUES ('$Pname_post', '$Pprice_post', '$filename', $sub_category_id_post, $staffid_post)";
            $con->query($sql);
            echo "<h4 class='text-success'>Product inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields and upload an image.</h4>";
        }
    }

    if($_POST['btn_product'] == "Update"){
        if($Pname_post != "" && $Pprice_post != "" && $sub_category_id_post != "" && $staffid_post != ""){
            $sql = "UPDATE product SET Pname='$Pname_post', Pprice='$Pprice_post', 
                    Pimage='$filename', sub_category_id=$sub_category_id_post, staffid=$staffid_post 
                    WHERE Pid=$Pid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Product updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $Pid = "";
    $Pname = "";
    $Pprice = "";
    $Pimage = "";
    $sub_category_id = "";
    $staffid = "";
    $btnname = "Insert";
}

if(isset($_GET['dPid'])){
    $dPid = $_GET['dPid'];
    $deleted_at = date('Y-m-d H:i:s');
    $sql = "UPDATE product SET deleted_at='$deleted_at' WHERE Pid=$dPid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Products</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 700px; margin:auto;">
    <form action="" method="post" enctype="multipart/form-data">
        <input type="hidden" name="Pid" value="<?php echo $Pid; ?>">
        <input type="hidden" name="old_Pimage" value="<?php echo $Pimage; ?>">

        <div class="mb-3">
            <label for="Pname" class="form-label">Product Name</label>
            <input type="text" name="Pname" id="Pname" required class="form-control" value="<?php echo $Pname; ?>">
        </div>

        <div class="mb-3">
            <label for="Pprice" class="form-label">Product Price</label>
            <input type="number" name="Pprice" id="Pprice" required class="form-control" value="<?php echo $Pprice; ?>" step="0.01">
        </div>

        <div class="mb-3">
            <label for="sub_category_id" class="form-label">Sub Category</label>
            <select name="sub_category_id" id="sub_category_id" required class="form-select">
                <option value="">-- Select Sub Category --</option>
                <?php
                $sc_sql = "SELECT * FROM sub_categories WHERE deleted_at IS NULL";
                $sc_query = mysqli_query($con, $sc_sql);
                while($sc = mysqli_fetch_assoc($sc_query)){
                    $selected = ($sc['scid'] == $sub_category_id) ? "selected" : "";
                    echo "<option value='{$sc['scid']}' $selected>{$sc['scname']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="staffid" class="form-label">Staff</label>
            <select name="staffid" id="staffid" required class="form-select">
                <option value="">-- Select Staff --</option>
                <?php
                $staff_sql = "SELECT * FROM staff";
                $staff_query = mysqli_query($con, $staff_sql);
                while($staff = mysqli_fetch_assoc($staff_query)){
                    $selected = ($staff['staffid'] == $staffid) ? "selected" : "";
                    echo "<option value='{$staff['staffid']}' $selected>{$staff['susername']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="Pimage" class="form-label">Product Image</label>
            <input type="file" name="Pimage" id="Pimage" class="form-control">
            <?php if($Pimage != ""): ?>
                <small>Current Image: <img src="../images/<?php echo $Pimage; ?>" width="80"></small>
            <?php endif; ?>
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_product" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Product ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Sub Category</th>
                <th>Staff</th>
                <th>Image</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT p.Pid, p.Pname, p.Pprice, p.Pimage, p.sub_category_id, p.staffid,
                           sc.scname, s.susername
                    FROM product p
                    LEFT JOIN sub_categories sc ON p.sub_category_id = sc.scid
                    LEFT JOIN staff s ON p.staffid = s.staffid
                    WHERE p.deleted_at IS NULL";

            if(isset($_GET['search_data']) && $_GET['search_data'] != ""){
                $search = mysqli_real_escape_string($con, $_GET['search_data']);
                $sql .= " AND p.Pname LIKE '%$search%'";
            }

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    echo "
                    <tr>
                        <td>{$row['Pid']}</td>
                        <td>{$row['Pname']}</td>
                        <td>{$row['Pprice']}</td>
                        <td>{$row['scname']}</td>
                        <td>{$row['susername']}</td>
                        <td><img src='../images/{$row['Pimage']}' width='100'></td>
                        <td>
                            <a href='?Pid={$row['Pid']}&Pname={$row['Pname']}&Pprice={$row['Pprice']}&sub_category_id={$row['sub_category_id']}&staffid={$row['staffid']}&Pimage={$row['Pimage']}' class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dPid={$row['Pid']}' class='btn btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this product?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='8' class='text-center'>No products found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
