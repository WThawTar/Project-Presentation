<?php
include("../connect.php");

$cid = "";
$cname = "";
$btnname = "Insert";

if (isset($_GET['cid'])) {
    $cid = $_GET['cid'];
    $cname = $_GET['cname'];
    $btnname = "Update";
}

if (isset($_POST['btn_category'])) {
    $cname_post = $_POST['cname'];

    if ($_POST['btn_category'] == "Insert") {
        $sql_insert = "INSERT INTO categories (cname) VALUES ('$cname_post')";
        $con->query($sql_insert);
    } else { 
        $cid = $_POST['cid'];
        $sql_update = "UPDATE categories SET cname='$cname_post' WHERE cid=$cid";
        $con->query($sql_update);
    }


    $cid = "";
    $cname = "";
    $btnname = "Insert";

}

if (isset($_GET['dcid'])) {
    $dcid = $_GET['dcid'];
    $sql_delete = "DELETE FROM categories WHERE cid=$dcid";
    $con->query($sql_delete);

}
?>

<h3 class="text-center mb-4">Manage Category</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 500px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="cid" value="<?php echo $cid; ?>">

        <div class="mb-3">
            <label for="cname" class="form-label">Category Name</label>
            <input type="text" name="cname" id="cname" required class="form-control" value="<?php echo $cname; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_category" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Category Id</th>
                <th>Category Name</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM categories";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['cid']}</td>
                            <td>{$row['cname']}</td>
                            <td>
                                <a href='index.php?cid={$row['cid']}&cname={$row['cname']}' class='btn btn-outline-primary'>Update</a>
                            </td>
                            <td>
                                <a href='index.php?dcid={$row['cid']}' onclick=\"return confirm('Are you sure you want to delete this category?')\" class='btn btn-outline-danger'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No categories found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
