<?php
include("../connect.php");

$uadminid = "";
$user_name = "";
$user_password = "";
$btnname = "Insert";

if (isset($_GET['uadminid'])) {
    $uadminid = $_GET['uadminid'];
    $user_name = $_GET['uusername'];
    $user_password = $_GET['upassword'];
    $btnname = "Update";
}

if (isset($_POST['btn_admin'])) {
    
    if ($_POST['btn_admin'] == "Insert") {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql_insert = "INSERT INTO admin (username, password) VALUES ('$username', '$password')";
        $con->query($sql_insert);

    } else { 
        $uadminid = $_POST['uadminid'];
        $user_name = $_POST['username'];
        $user_password = $_POST['password'];

        $sql_update = "UPDATE admin SET username='$user_name', password='$user_password' WHERE adminid=$uadminid";
        $con->query($sql_update);
    }

    $uadminid = "";
    $user_name = "";
    $user_password = "";
    $btnname = "Insert";
}

if (isset($_GET['dadminid'])) {
    $dadminid = $_GET['dadminid'];
    $sql_delete = "DELETE FROM admin WHERE adminid=$dadminid";
    $con->query($sql_delete);
}
?>

<h3 class="text-center mb-4">Manage Admin</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 500px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="uadminid" value="<?php echo $uadminid; ?>">

        <div class="mb-3">
            <label for="username" class="form-label">Admin Username</label>
            <input type="text" name="username" id="username" required class="form-control" value="<?php echo $user_name; ?>">
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Admin Password</label>
            <input type="text" name="password" id="password" required class="form-control" value="<?php echo $user_password; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_admin" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Admin Id</th>
                <th>Admin Username</th>
                <th>Admin Password</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM admin";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['adminid']}</td>
                            <td>{$row['username']}</td>
                            <td>{$row['password']}</td>
                            <td><a href='index.php?uadminid={$row['adminid']}&uusername={$row['username']}&upassword={$row['password']}' class='btn btn-outline-primary'>Update</a></td>
                            <td><a href='index.php?dadminid={$row['adminid']}' onclick=\"return confirm('Are you sure you want to delete this admin?')\" class='btn btn-outline-danger'>Delete</a></td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No admins found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>

