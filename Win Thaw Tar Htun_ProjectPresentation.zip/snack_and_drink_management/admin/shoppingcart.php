<?php
include("../connect.php");

$shoppingcartid = "";
$orderid = "";
$cartqty = "";
$btnname = "Insert";

if(isset($_GET['shoppingcartid'])){
    $shoppingcartid = $_GET['shoppingcartid'];
    $orderid = $_GET['orderid'];
    $cartqty = $_GET['cartqty'];
    $btnname = "Update";
}

if(isset($_POST['btn_shoppingcart'])){
    $shoppingcartid_post = $_POST['shoppingcartid'];
    $orderid_post = $_POST['orderid'];
    $cartqty_post = $_POST['cartqty'];

    if($_POST['btn_shoppingcart'] == "Insert"){
        if($orderid_post != "" && $cartqty_post != ""){
            $sql = "INSERT INTO shoppingcart (orderid, cartqty) 
                    VALUES ('$orderid_post', '$cartqty_post')";
            $con->query($sql);
            echo "<h4 class='text-success'>Shopping Cart inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    if($_POST['btn_shoppingcart'] == "Update"){
        if($orderid_post != "" && $cartqty_post != ""){
            $sql = "UPDATE shoppingcart SET orderid='$orderid_post', cartqty='$cartqty_post' 
                    WHERE shoppingcartid=$shoppingcartid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Shopping Cart updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $shoppingcartid = "";
    $orderid = "";
    $cartqty = "";
    $btnname = "Insert";
}

if(isset($_GET['dshoppingcartid'])){
    $dshoppingcartid = $_GET['dshoppingcartid'];
    $sql = "DELETE FROM shoppingcart WHERE shoppingcartid=$dshoppingcartid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Shopping Carts</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 600px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="shoppingcartid" value="<?php echo $shoppingcartid; ?>">

        <div class="mb-3">
            <label for="orderid" class="form-label">Order</label>
            <select name="orderid" id="orderid" required class="form-select">
                <option value="">-- Select Order --</option>
                <?php
                $order_sql = "SELECT o.orderid, o.shoppingcartid, o.cusid, o.orderdate FROM orders o";
                $order_query = mysqli_query($con, $order_sql);
                while($order = mysqli_fetch_assoc($order_query)){
                    $display = "OrderID: ".$order['orderid']." | CustomerID: ".$order['cusid']." | Date: ".$order['orderdate'];
                    $selected = ($order['orderid'] == $orderid) ? "selected" : "";
                    echo "<option value='{$order['orderid']}' $selected>$display</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="cartqty" class="form-label">Cart Quantity</label>
            <input type="number" name="cartqty" id="cartqty" required class="form-control" value="<?php echo $cartqty; ?>" min="1">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_shoppingcart" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Shopping Cart ID</th>
                <th>Order Info</th>
                <th>Quantity</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT sc.shoppingcartid, sc.cartqty, o.orderid, o.cusid, o.orderdate 
                    FROM shoppingcart sc
                    LEFT JOIN orders o ON sc.orderid = o.orderid";

            if(isset($_GET['search_data']) && $_GET['search_data'] != ""){
                $search = mysqli_real_escape_string($con, $_GET['search_data']);
                $sql .= " WHERE sc.shoppingcartid LIKE '%$search%' OR o.cusid LIKE '%$search%'";
            }

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    $order_info = "OrderID: ".$row['orderid']." | CusID: ".$row['cusid']." | Date: ".$row['orderdate'];
                    echo "
                    <tr>
                        <td>{$row['shoppingcartid']}</td>
                        <td>$order_info</td>
                        <td>{$row['cartqty']}</td>
                        <td>
                            <a href='?shoppingcartid={$row['shoppingcartid']}&orderid={$row['orderid']}&cartqty={$row['cartqty']}' class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dshoppingcartid={$row['shoppingcartid']}' class='btn btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this shopping cart?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='text-center'>No shopping carts found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
