<?php
include("../connect.php");

$orderid = "";
$shoppingcartid = "";
$cusid = "";
$paymentid = "";
$orderdate = "";
$btnname = "Insert";

if(isset($_GET['orderid'])){
    $orderid = $_GET['orderid'];
    $shoppingcartid = $_GET['shoppingcartid'];
    $cusid = $_GET['cusid'];
    $paymentid = $_GET['paymentid'];
    $orderdate = $_GET['orderdate'];
    $btnname = "Update";
}

if(isset($_POST['btn_order'])){
    $orderid_post = $_POST['orderid'];
    $shoppingcartid_post = $_POST['shoppingcartid'];
    $cusid_post = $_POST['cusid'];
    $paymentid_post = $_POST['paymentid'];
    $orderdate_post = $_POST['orderdate'];

    if($_POST['btn_order'] == "Insert"){
        if($shoppingcartid_post != "" && $cusid_post != "" && $paymentid_post != "" && $orderdate_post != ""){
            $sql = "INSERT INTO orders (shoppingcartid, cusid, paymentid, orderdate) 
                    VALUES ($shoppingcartid_post, $cusid_post, $paymentid_post, '$orderdate_post')";
            $con->query($sql);
            echo "<h4 class='text-success'>Order inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    if($_POST['btn_order'] == "Update"){
        if($shoppingcartid_post != "" && $cusid_post != "" && $paymentid_post != "" && $orderdate_post != ""){
            $sql = "UPDATE orders SET shoppingcartid=$shoppingcartid_post, cusid=$cusid_post, 
                    paymentid=$paymentid_post, orderdate='$orderdate_post'
                    WHERE orderid=$orderid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Order updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $orderid = "";
    $shoppingcartid = "";
    $cusid = "";
    $paymentid = "";
    $orderdate = "";
    $btnname = "Insert";
}

if(isset($_GET['dorderid'])){
    $dorderid = $_GET['dorderid'];
    $sql = "DELETE FROM orders WHERE orderid=$dorderid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Orders</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 700px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="orderid" value="<?php echo $orderid; ?>">

        <div class="mb-3">
            <label for="shoppingcartid" class="form-label">Shopping Cart</label>
            <select name="shoppingcartid" id="shoppingcartid" required class="form-select">
                <option value="">-- Select Shopping Cart --</option>
                <?php
                $cart_sql = "SELECT sc.shoppingcartid, o.orderid AS o_id, sc.cartqty FROM shoppingcart sc
                             LEFT JOIN orders o ON sc.orderid = o.orderid";
                $cart_query = mysqli_query($con, $cart_sql);
                while($sc = mysqli_fetch_assoc($cart_query)){
                    $display = "CartID: ".$sc['shoppingcartid']." | OrderID: ".$sc['o_id']." | Qty: ".$sc['cartqty'];
                    $selected = ($sc['shoppingcartid'] == $shoppingcartid) ? "selected" : "";
                    echo "<option value='{$sc['shoppingcartid']}' $selected>$display</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="cusid" class="form-label">Customer</label>
            <select name="cusid" id="cusid" required class="form-select">
                <option value="">-- Select Customer --</option>
                <?php
                $cus_sql = "SELECT cusid, cusname FROM customer";
                $cus_query = mysqli_query($con, $cus_sql);
                while($c = mysqli_fetch_assoc($cus_query)){
                    $selected = ($c['cusid'] == $cusid) ? "selected" : "";
                    echo "<option value='{$c['cusid']}' $selected>{$c['cusname']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="paymentid" class="form-label">Payment</label>
            <select name="paymentid" id="paymentid" required class="form-select">
                <option value="">-- Select Payment --</option>
                <?php
                $pay_sql = "SELECT paymentid, paymentamount, paymentdate FROM payment";
                $pay_query = mysqli_query($con, $pay_sql);
                while($p = mysqli_fetch_assoc($pay_query)){
                    $display = "PaymentID: ".$p['paymentid']." | Amount: ".$p['paymentamount']." | Date: ".$p['paymentdate'];
                    $selected = ($p['paymentid'] == $paymentid) ? "selected" : "";
                    echo "<option value='{$p['paymentid']}' $selected>$display</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="orderdate" class="form-label">Order Date</label>
            <input type="date" name="orderdate" id="orderdate" required class="form-control" value="<?php echo $orderdate; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_order" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Order ID</th>
                <th>Shopping Cart</th>
                <th>Customer</th>
                <th>Payment</th>
                <th>Order Date</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT o.orderid, o.shoppingcartid, o.cusid, o.paymentid, o.orderdate,
                           sc.cartqty, c.cusname, p.paymentamount, p.paymentdate AS paydate
                    FROM orders o
                    LEFT JOIN shoppingcart sc ON o.shoppingcartid = sc.shoppingcartid
                    LEFT JOIN customer c ON o.cusid = c.cusid
                    LEFT JOIN payment p ON o.paymentid = p.paymentid";

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    $cart_info = "CartID: ".$row['shoppingcartid']." | Qty: ".$row['cartqty'];
                    $payment_info = "Amount: ".$row['paymentamount']." | Date: ".$row['paydate'];
                    echo "
                    <tr>
                        <td>{$row['orderid']}</td>
                        <td>$cart_info</td>
                        <td>{$row['cusname']}</td>
                        <td>$payment_info</td>
                        <td>{$row['orderdate']}</td>
                        <td>
                            <a href='?orderid={$row['orderid']}&shoppingcartid={$row['shoppingcartid']}&cusid={$row['cusid']}&paymentid={$row['paymentid']}&orderdate={$row['orderdate']}' class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dorderid={$row['orderid']}' class='btn btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this order?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7' class='text-center'>No orders found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>