<?php
include("../connect.php");

$paymentid = "";
$paymentamount = "";
$paymentdate = "";
$paymenttype = "";
$btnname = "Insert";

if (isset($_GET['paymentid'])) {
    $paymentid = $_GET['paymentid'];
    $paymentamount = $_GET['paymentamount'];
    $paymentdate = $_GET['paymentdate'];
    $paymenttype = $_GET['paymenttype'];
    $btnname = "Update";
}

if (isset($_POST['btn_payment'])) {
    $paymentamount_post = $_POST['paymentamount'];
    $paymentdate_post = $_POST['paymentdate'];
    $paymenttype_post = $_POST['paymenttype'];

    if ($_POST['btn_payment'] == "Insert") {
        $sql_insert = "INSERT INTO payment (paymentamount, paymentdate, paymenttype) VALUES ('$paymentamount_post', '$paymentdate_post', '$paymenttype_post')";
        $con->query($sql_insert);
    } else { 
        $paymentid = $_POST['paymentid'];
        $sql_update = "UPDATE payment SET paymentamount='$paymentamount_post', paymentdate='$paymentdate_post', paymenttype='$paymenttype_post' WHERE paymentid=$paymentid";
        $con->query($sql_update);
    }

    $paymentid = "";
    $paymentamount = "";
    $paymentdate = "";
    $paymenttype = "";
    $btnname = "Insert";
}

if (isset($_GET['dpaymentid'])) {
    $dpaymentid = $_GET['dpaymentid'];
    $sql_delete = "DELETE FROM payment WHERE paymentid=$dpaymentid";
    $con->query($sql_delete);
}
?>

<h3 class="text-center mb-4">Manage Payment</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 600px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="paymentid" value="<?php echo $paymentid; ?>">

        <div class="mb-3">
            <label for="paymentamount" class="form-label">Payment Amount</label>
            <input type="number" step="0.01" name="paymentamount" id="paymentamount" required class="form-control" value="<?php echo $paymentamount; ?>">
        </div>

        <div class="mb-3">
            <label for="paymentdate" class="form-label">Payment Date</label>
            <input type="date" name="paymentdate" id="paymentdate" required class="form-control" value="<?php echo $paymentdate; ?>">
        </div>

        <div class="mb-3">
            <label for="paymenttype" class="form-label">Payment Type</label>
            <input type="text" name="paymenttype" id="paymenttype" required class="form-control" value="<?php echo $paymenttype; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_payment" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Payment Id</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Payment Type</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM payment";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['paymentid']}</td>
                            <td>{$row['paymentamount']}</td>
                            <td>{$row['paymentdate']}</td>
                            <td>{$row['paymenttype']}</td>
                            <td>
                                <a href='index.php?paymentid={$row['paymentid']}&paymentamount={$row['paymentamount']}&paymentdate={$row['paymentdate']}&paymenttype={$row['paymenttype']}' class='btn btn-outline-primary'>Update</a>
                            </td>
                            <td>
                                <a href='index.php?dpaymentid={$row['paymentid']}' onclick=\"return confirm('Are you sure you want to delete this payment?')\" class='btn btn-outline-danger'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No payments found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
