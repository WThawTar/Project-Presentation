<?php
include("../connect.php");

$orderdetailid = "";
$orderid = "";
$pid = "";
$qty = "";
$price = "";
$total = "";
$btnname = "Insert";

if(isset($_GET['orderdetailid'])){
    $orderdetailid = $_GET['orderdetailid'];
    $orderid = $_GET['orderid'];
    $pid = $_GET['pid'];
    $qty = $_GET['qty'];
    $price = $_GET['price'];
    $total = $_GET['total'];
    $btnname = "Update";
}

if(isset($_POST['btn_orderdetail'])){
    $orderdetailid_post = $_POST['orderdetailid'];
    $orderid_post = $_POST['orderid'];
    $pid_post = $_POST['pid'];
    $qty_post = $_POST['qty'];
    $price_post = $_POST['price'];
    $total_post = $qty_post * $price_post;

    if($_POST['btn_orderdetail'] == "Insert"){
        if($orderid_post != "" && $pid_post != "" && $qty_post != "" && $price_post != ""){
            $sql = "INSERT INTO order_details (orderid, pid, qty, price, total) 
                    VALUES ($orderid_post, $pid_post, $qty_post, $price_post, $total_post)";
            $con->query($sql);
            echo "<h4 class='text-success'>Order detail inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    if($_POST['btn_orderdetail'] == "Update"){
        if($orderid_post != "" && $pid_post != "" && $qty_post != "" && $price_post != ""){
            $sql = "UPDATE order_details 
                    SET orderid=$orderid_post, pid=$pid_post, qty=$qty_post, price=$price_post, total=$total_post
                    WHERE orderdetailid=$orderdetailid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Order detail updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $orderdetailid = "";
    $orderid = "";
    $pid = "";
    $qty = "";
    $price = "";
    $total = "";
    $btnname = "Insert";
}

if(isset($_GET['dorderdetailid'])){
    $dorderdetailid = $_GET['dorderdetailid'];
    $sql = "DELETE FROM order_details WHERE orderdetailid=$dorderdetailid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Order Details</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 600px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="orderdetailid" value="<?php echo $orderdetailid; ?>">

        <div class="mb-3">
            <label for="orderid" class="form-label">Order</label>
            <select name="orderid" id="orderid" required class="form-select">
                <option value="">-- Select Order --</option>
                <?php
                $o_sql = "SELECT orderid, orderdate FROM orders";
                $o_query = mysqli_query($con, $o_sql);
                while($o = mysqli_fetch_assoc($o_query)){
                    $selected = ($o['orderid'] == $orderid) ? "selected" : "";
                    echo "<option value='{$o['orderid']}' $selected>Order ID: {$o['orderid']} | Date: {$o['orderdate']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="pid" class="form-label">Product</label>
            <select name="pid" id="pid" required class="form-select">
                <option value="">-- Select Product --</option>
                <?php
                $p_sql = "SELECT Pid, Pname FROM product";
                $p_query = mysqli_query($con, $p_sql);
                while($p = mysqli_fetch_assoc($p_query)){
                    $selected = ($p['Pid'] == $pid) ? "selected" : "";
                    echo "<option value='{$p['Pid']}' $selected>{$p['Pname']} (ID: {$p['Pid']})</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="qty" class="form-label">Quantity</label>
            <input type="number" name="qty" id="qty" min="1" required class="form-control" value="<?php echo $qty; ?>">
        </div>

        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="number" name="price" id="price" min="0" step="0.01" required class="form-control" value="<?php echo $price; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_orderdetail" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Detail ID</th>
                <th>Order ID</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT od.orderdetailid, od.orderid, od.pid, od.qty, od.price, od.total, p.Pname
                    FROM order_details od
                    LEFT JOIN product p ON od.pid = p.Pid
                    ORDER BY od.orderdetailid DESC";
            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    echo "
                    <tr>
                        <td>{$row['orderdetailid']}</td>
                        <td>{$row['orderid']}</td>
                        <td>{$row['Pname']}</td>
                        <td>{$row['qty']}</td>
                        <td>$ {$row['price']}</td>
                        <td>$ {$row['total']}</td>
                        <td>
                            <a href='?orderdetailid={$row['orderdetailid']}&orderid={$row['orderid']}&pid={$row['pid']}&qty={$row['qty']}&price={$row['price']}&total={$row['total']}' class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?dorderdetailid={$row['orderdetailid']}' class='btn btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this order detail?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='8' class='text-center'>No order details found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
