<?php
include("../connect.php");

$order_from = isset($_GET['order_from']) ? $_GET['order_from'] : "";
$order_to   = isset($_GET['order_to']) ? $_GET['order_to'] : "";

$order_filter = "";
if ($order_from != "" && $order_to != "") {
    $order_filter = " AND o.orderdate BETWEEN '$order_from' AND '$order_to' ";
}

$del_from = isset($_GET['del_from']) ? $_GET['del_from'] : "";
$del_to   = isset($_GET['del_to']) ? $_GET['del_to'] : "";

$delivery_filter = "";
if ($del_from != "" && $del_to != "") {
    $delivery_filter = " AND pc.paymentconfirmdate BETWEEN '$del_from' AND '$del_to' ";
}

$active_tab = isset($_GET['active_tab']) ? $_GET['active_tab'] : "orders";
?>

<div class="container my-5">
    <h2 class="text-center mb-4">Admin Reports</h2>

    <ul class="nav nav-tabs mb-4" id="reportTabs" role="tablist">
        <li class="nav-item">
            <button class="nav-link <?php echo ($active_tab=='orders'?'active':''); ?>" 
                id="orders-tab" data-bs-toggle="tab" data-bs-target="#orders" type="button">Orders</button>
        </li>

        <li class="nav-item">
            <button class="nav-link <?php echo ($active_tab=='deliveries'?'active':''); ?>" 
                id="deliveries-tab" data-bs-toggle="tab" data-bs-target="#deliveries" type="button">Deliveries</button>
        </li>

        <li class="nav-item">
            <button class="nav-link <?php echo ($active_tab=='staff'?'active':''); ?>" 
                id="staff-tab" data-bs-toggle="tab" data-bs-target="#staff" type="button">Staff & Admin</button>
        </li>
    </ul>

    <div class="tab-content">

        <div class="tab-pane fade <?php echo ($active_tab=='orders'?'show active':''); ?>" id="orders">

            <!-- Filter Form -->
            <form method="GET" class="row g-3 mb-3">
                <input type="hidden" name="active_tab" value="orders">

                <div class="col-md-3">
                    <label class="form-label">From Date</label>
                    <input type="date" name="order_from" value="<?php echo $order_from; ?>" class="form-control">
                </div>

                <div class="col-md-3">
                    <label class="form-label">To Date</label>
                    <input type="date" name="order_to" value="<?php echo $order_to; ?>" class="form-control">
                </div>

                <div class="col-md-3 d-flex align-items-end">
                    <button class="btn btn-primary">Filter</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Order Date</th>
                            <th>Customer Name</th>
                            <th>Payment Amount</th>
                            <th>Payment Type</th>
                            <th>Total</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php
                    $order_sql = "SELECT o.orderid, o.orderdate, c.cusname, pay.paymentamount, pay.paymenttype
                                  FROM orders o
                                  LEFT JOIN customer c ON o.cusid = c.cusid
                                  LEFT JOIN payment pay ON o.paymentid = pay.paymentid
                                  WHERE 1=1 $order_filter
                                  ORDER BY o.orderid DESC";

                    $order_query = mysqli_query($con, $order_sql);
                    $no = 1; $total_revenue = 0;
                    if (mysqli_num_rows($order_query) > 0) {
                        while ($row = mysqli_fetch_assoc($order_query)) {
                            $total_revenue += $row['paymentamount'];
                            echo "<tr class='text-center'>
                                    <td>$no</td>
                                    <td>{$row['orderdate']}</td>
                                    <td>{$row['cusname']}</td>
                                    <td>$ {$row['paymentamount']}</td>
                                    <td>{$row['paymenttype']}</td>
                                    <td>$ {$row['paymentamount']}</td>
                                  </tr>";
                            $no++;
                        }

                        echo "<tr class='table-light fw-bold text-center'>
                                <td colspan='5'>Total Revenue</td>
                                <td>$ {$total_revenue}</td>
                              </tr>";
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No orders found.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="tab-pane fade <?php echo ($active_tab=='deliveries'?'show active':''); ?>" id="deliveries">

            <!-- Delivery Filter -->
            <form method="GET" class="row g-3 mb-3">
                <input type="hidden" name="active_tab" value="deliveries">

                <div class="col-md-3">
                    <label class="form-label">From Date</label>
                    <input type="date" name="del_from" value="<?php echo $del_from; ?>" class="form-control">
                </div>

                <div class="col-md-3">
                    <label class="form-label">To Date</label>
                    <input type="date" name="del_to" value="<?php echo $del_to; ?>" class="form-control">
                </div>

                <div class="col-md-3 d-flex align-items-end">
                    <button class="btn btn-primary">Filter</button>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Order ID</th>
                            <th>Delivery Type</th>
                            <th>Delivery Address</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php
                    $delivery_sql = "SELECT d.deliveryid, o.orderid, dt.deliverytype, d.deliveryaddress
                                     FROM delivery d
                                     LEFT JOIN deliverytype dt ON d.deliverytypeid = dt.deliverytypeid
                                     LEFT JOIN paymentconfirm pc ON d.paymentconfirmid = pc.paymentconfirmid
                                     LEFT JOIN orders o ON o.paymentid = pc.paymentconfirmid
                                     WHERE 1=1 $delivery_filter
                                     ORDER BY d.deliveryid DESC";

                    $delivery_query = mysqli_query($con, $delivery_sql);
                    $no = 1;
                    if (mysqli_num_rows($delivery_query) > 0) {
                        while ($row = mysqli_fetch_assoc($delivery_query)) {
                            echo "<tr class='text-center'>
                                    <td>$no</td>
                                    <td>{$row['orderid']}</td>
                                    <td>{$row['deliverytype']}</td>
                                    <td>{$row['deliveryaddress']}</td>
                                  </tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='4' class='text-center'>No deliveries found.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="tab-pane fade <?php echo ($active_tab=='staff'?'show active':''); ?>" id="staff">

            <h4 class="mt-3">Staff Accounts</h4>
            <table class="table table-bordered table-hover mt-2">
                <thead class="table-dark text-center">
                    <tr><th>No</th><th>Staff Username</th><th>Password (hashed)</th></tr>
                </thead>

                <tbody>
                <?php
                $stf = mysqli_query($con, "SELECT * FROM staff");
                $no = 1;
                while ($r = mysqli_fetch_assoc($stf)) {
                    echo "<tr class='text-center'>
                            <td>$no</td>
                            <td>{$r['susername']}</td>
                            <td>{$r['spassword']}</td>
                          </tr>";
                    $no++;
                }
                ?>
                </tbody>
            </table>

            <h4 class="mt-4">Admin Accounts</h4>
            <table class="table table-bordered table-hover mt-2">
                <thead class="table-dark text-center">
                    <tr><th>No</th><th>Admin Username</th><th>Password (hashed)</th></tr>
                </thead>

                <tbody>
                <?php
                $adm = mysqli_query($con, "SELECT * FROM admin");
                $no = 1;
                while ($r = mysqli_fetch_assoc($adm)) {
                    echo "<tr class='text-center'>
                            <td>$no</td>
                            <td>{$r['username']}</td>
                            <td>{$r['password']}</td>
                          </tr>";
                    $no++;
                }
                ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>