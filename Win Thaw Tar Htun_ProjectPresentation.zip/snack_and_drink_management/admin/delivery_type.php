<?php
include("../connect.php");

$deliverytypeid = "";
$deliverytype = "";
$btnname = "Insert";

// Handle update form pre-fill
if (isset($_GET['deliverytypeid'])) {
    $deliverytypeid = $_GET['deliverytypeid'];
    $deliverytype = $_GET['deliverytype'];
    $btnname = "Update";
}

// Handle insert or update
if (isset($_POST['btn_deliverytype'])) {
    $deliverytype_post = $_POST['deliverytype'];

    if ($_POST['btn_deliverytype'] == "Insert") {
        $sql_insert = "INSERT INTO deliverytype (deliverytype) VALUES ('$deliverytype_post')";
        $con->query($sql_insert);
    } else { // Update
        $deliverytypeid = $_POST['deliverytypeid'];
        $sql_update = "UPDATE deliverytype SET deliverytype='$deliverytype_post' WHERE deliverytypeid=$deliverytypeid";
        $con->query($sql_update);
    }

    // Reset form
    $deliverytypeid = "";
    $deliverytype = "";
    $btnname = "Insert";
}

// Handle delete
if (isset($_GET['ddeliverytypeid'])) {
    $ddeliverytypeid = $_GET['ddeliverytypeid'];
    $sql_delete = "DELETE FROM deliverytype WHERE deliverytypeid=$ddeliverytypeid";
    $con->query($sql_delete);
}
?>

<h3 class="text-center mb-4">Manage Delivery Type</h3>

<!-- Delivery Type Form -->
<div class="card p-4 mb-5 shadow-sm" style="max-width: 500px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="deliverytypeid" value="<?php echo $deliverytypeid; ?>">

        <div class="mb-3">
            <label for="deliverytype" class="form-label">Delivery Type</label>
            <input type="text" name="deliverytype" id="deliverytype" required class="form-control" value="<?php echo $deliverytype; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_deliverytype" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<!-- Delivery Type Table -->
<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Delivery Type Id</th>
                <th>Delivery Type</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM deliverytype";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['deliverytypeid']}</td>
                            <td>{$row['deliverytype']}</td>
                            <td>
                                <a href='index.php?deliverytypeid={$row['deliverytypeid']}&deliverytype={$row['deliverytype']}' class='btn btn-outline-primary'>Update</a>
                            </td>
                            <td>
                                <a href='index.php?ddeliverytypeid={$row['deliverytypeid']}' onclick=\"return confirm('Are you sure you want to delete this delivery type?')\" class='btn btn-outline-danger'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No delivery types found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
