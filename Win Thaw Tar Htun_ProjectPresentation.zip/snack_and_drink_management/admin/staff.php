<?php
include("../connect.php");

$staffid = "";
$susername = "";
$spassword = "";
$btnname = "Insert";

if (isset($_GET['staffid'])) {
    $staffid = $_GET['staffid'];
    $susername = $_GET['susername'];
    $spassword = $_GET['spassword'];
    $btnname = "Update";
}

if (isset($_POST['btn_staff'])) {
    $susername_post = $_POST['susername'];
    $spassword_post = $_POST['spassword'];

    if ($_POST['btn_staff'] == "Insert") {
        $sql_insert = "INSERT INTO staff (susername, spassword) VALUES ('$susername_post', '$spassword_post')";
        $con->query($sql_insert);
    } else { 
        $staffid = $_POST['staffid'];
        $sql_update = "UPDATE staff SET susername='$susername_post', spassword='$spassword_post' WHERE staffid=$staffid";
        $con->query($sql_update);
    }

    $staffid = "";
    $susername = "";
    $spassword = "";
    $btnname = "Insert";
}

if (isset($_GET['dstaffid'])) {
    $dstaffid = $_GET['dstaffid'];
    $sql_delete = "DELETE FROM staff WHERE staffid=$dstaffid";
    $con->query($sql_delete);
}
?>

<h3 class="text-center mb-4">Manage Staff</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 500px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="staffid" value="<?php echo $staffid; ?>">

        <div class="mb-3">
            <label for="susername" class="form-label">Staff Username</label>
            <input type="text" name="susername" id="susername" required class="form-control" value="<?php echo $susername; ?>">
        </div>

        <div class="mb-3">
            <label for="spassword" class="form-label">Staff Password</label>
            <input type="text" name="spassword" id="spassword" required class="form-control" value="<?php echo $spassword; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_staff" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-striped table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Staff Id</th>
                <th>Staff Username</th>
                
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
                $sql = "SELECT * FROM staff";
                $query = mysqli_query($con, $sql);

                if (mysqli_num_rows($query) > 0) {
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo "
                        <tr>
                            <td>{$row['staffid']}</td>
                            <td>{$row['susername']}</td>
                            
                            <td>
                                <a href='index.php?staffid={$row['staffid']}&susername={$row['susername']}&spassword={$row['spassword']}' class='btn btn-outline-primary'>Update</a>
                            </td>
                            <td>
                                <a href='index.php?dstaffid={$row['staffid']}' onclick=\"return confirm('Are you sure you want to delete this staff?')\" class='btn btn-outline-danger'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No staff found.</td></tr>";
                }
            ?>
        </tbody>
    </table>
</div>
