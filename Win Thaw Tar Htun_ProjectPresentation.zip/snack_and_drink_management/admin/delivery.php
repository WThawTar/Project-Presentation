<?php
include("../connect.php");

$deliveryid = "";
$paymentconfirmid = "";
$deliverytypeid = "";
$deliveryaddress = "";
$btnname = "Insert";

if(isset($_GET['deliveryid'])){
    $deliveryid = $_GET['deliveryid'];
    $paymentconfirmid = $_GET['paymentconfirmid'];
    $deliverytypeid = $_GET['deliverytypeid'];
    $deliveryaddress = $_GET['deliveryaddress'];
    $btnname = "Update";
}

if(isset($_POST['btn_delivery'])){
    $deliveryid_post = $_POST['deliveryid'];
    $paymentconfirmid_post = $_POST['paymentconfirmid'];
    $deliverytypeid_post = $_POST['deliverytypeid'];
    $deliveryaddress_post = trim($_POST['deliveryaddress']);

    if($_POST['btn_delivery'] == "Insert"){
        if($paymentconfirmid_post != "" && $deliverytypeid_post != "" && $deliveryaddress_post != ""){
            $sql = "INSERT INTO delivery (paymentconfirmid, deliverytypeid, deliveryaddress)
                    VALUES ($paymentconfirmid_post, $deliverytypeid_post, '$deliveryaddress_post')";
            $con->query($sql);
            echo "<h4 class='text-success'>Delivery inserted successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    if($_POST['btn_delivery'] == "Update"){
        if($paymentconfirmid_post != "" && $deliverytypeid_post != "" && $deliveryaddress_post != ""){
            $sql = "UPDATE delivery SET paymentconfirmid=$paymentconfirmid_post, deliverytypeid=$deliverytypeid_post,
                    deliveryaddress='$deliveryaddress_post' WHERE deliveryid=$deliveryid_post";
            $con->query($sql);
            echo "<h4 class='text-success'>Delivery updated successfully!</h4>";
        } else {
            echo "<h4 class='text-danger'>Please fill all fields.</h4>";
        }
    }

    $deliveryid = "";
    $paymentconfirmid = "";
    $deliverytypeid = "";
    $deliveryaddress = "";
    $btnname = "Insert";
}

if(isset($_GET['ddeliveryid'])){
    $ddeliveryid = $_GET['ddeliveryid'];
    $sql = "DELETE FROM delivery WHERE deliveryid=$ddeliveryid";
    $con->query($sql);
}
?>

<h3 class="text-center mb-4">Manage Deliveries</h3>

<div class="card p-4 mb-5 shadow-sm" style="max-width: 600px; margin:auto;">
    <form action="" method="post">
        <input type="hidden" name="deliveryid" value="<?php echo $deliveryid; ?>">

        <div class="mb-3">
            <label for="paymentconfirmid" class="form-label">Payment Confirmation</label>
            <select name="paymentconfirmid" id="paymentconfirmid" required class="form-select">
                <option value="">-- Select Payment Confirmation --</option>
                <?php
                $pc_sql = "SELECT paymentconfirmid, paymentconfirmdate FROM paymentconfirm";
                $pc_query = mysqli_query($con, $pc_sql);
                while($pc = mysqli_fetch_assoc($pc_query)){
                    $selected = ($pc['paymentconfirmid'] == $paymentconfirmid) ? "selected" : "";
                    echo "<option value='{$pc['paymentconfirmid']}' $selected>Payment ID: {$pc['paymentconfirmid']} | Date: {$pc['paymentconfirmdate']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="deliverytypeid" class="form-label">Delivery Type</label>
            <select name="deliverytypeid" id="deliverytypeid" required class="form-select">
                <option value="">-- Select Delivery Type --</option>
                <?php
                $dt_sql = "SELECT deliverytypeid, deliverytype FROM deliverytype";
                $dt_query = mysqli_query($con, $dt_sql);
                while($dt = mysqli_fetch_assoc($dt_query)){
                    $selected = ($dt['deliverytypeid'] == $deliverytypeid) ? "selected" : "";
                    echo "<option value='{$dt['deliverytypeid']}' $selected>{$dt['deliverytype']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="deliveryaddress" class="form-label">Delivery Address</label>
            <input type="text" name="deliveryaddress" id="deliveryaddress" required class="form-control" value="<?php echo $deliveryaddress; ?>">
        </div>

        <div class="text-center">
            <input type="submit" value="<?php echo $btnname; ?>" name="btn_delivery" class="btn btn-dark px-4">
        </div>
    </form>
</div>

<div class="table-responsive">
    <table class="table table-primary table-hover table-bordered align-middle">
        <thead class="table-primary text-center">
            <tr>
                <th>Delivery ID</th>
                <th>Payment Confirmation</th>
                <th>Delivery Type</th>
                <th>Address</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php
            $sql = "SELECT d.deliveryid, d.deliveryaddress,
                           pc.paymentconfirmid, pc.paymentconfirmdate,
                           dt.deliverytypeid, dt.deliverytype
                    FROM delivery d
                    LEFT JOIN paymentconfirm pc ON d.paymentconfirmid = pc.paymentconfirmid
                    LEFT JOIN deliverytype dt ON d.deliverytypeid = dt.deliverytypeid";

            $query = mysqli_query($con, $sql);
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    $payment_info = "ID: ".$row['paymentconfirmid']." | Date: ".$row['paymentconfirmdate'];
                    echo "
                    <tr>
                        <td>{$row['deliveryid']}</td>
                        <td>$payment_info</td>
                        <td>{$row['deliverytype']}</td>
                        <td>{$row['deliveryaddress']}</td>
                        <td>
                            <a href='?deliveryid={$row['deliveryid']}&paymentconfirmid={$row['paymentconfirmid']}&deliverytypeid={$row['deliverytypeid']}&deliveryaddress={$row['deliveryaddress']}' class='btn btn-outline-primary'>Update</a>
                        </td>
                        <td>
                            <a href='?ddeliveryid={$row['deliveryid']}' class='btn btn-outline-danger' onclick=\"return confirm('Are you sure you want to delete this delivery?')\">Delete</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>No deliveries found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
