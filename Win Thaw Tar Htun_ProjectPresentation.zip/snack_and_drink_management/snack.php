<?php include("header.php"); ?>
<?php include("connect.php"); ?>

<div class="container">
    <div class="row packagemargin">

        <div class="row">
            <?php
                $sql = "SELECT * FROM Product";
                $result = mysqli_query($con, $sql);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "
                        <div class='col-lg-3 col-md-6'>
                            <div class='card mb-3 shadow rounded packagecard'>
                                <img class='card-img-top packageimg' src='images/{$row['Pimage']}' alt='Card image cap'>
                                <div class='card-body'>
                                    <h5 class='card-title'>{$row['Pname']}</h5>
                                    <p class='card-text'>Price: $ {$row['Pprice']}</p>
                                    <a href='snack.php?osid={$row['Pid']}' class='btn btn-primary w-100 mt-2 rounded-3 package-btn'>Order Now</a>
                                </div>
                            </div>
                        </div>
                    ";
                }
            ?>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>
