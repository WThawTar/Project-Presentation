<?php 
session_start();

if (isset($_GET['delete'])) {
    unset($_SESSION['product_cart']);
}

$product_carttotal = 0;
if (isset($_GET["osid"])) {
    $osid = $_GET["osid"];
    if (!isset($_SESSION["product_cart"][$osid])) {
        $_SESSION["product_cart"][$osid] = 1;
    } else {
        $_SESSION["product_cart"][$osid]++;
    }
}

if (isset($_SESSION["product_cart"])) {
    foreach ($_SESSION["product_cart"] as $Pid => $qty) {
        $product_carttotal += $qty;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>The Alley Snack And Drinks</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="format-detection" content="telephone=no">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="author" content="TemplatesJungle">
  <meta name="keywords" content="ecommerce,fashion,store">
  <meta name="description" content="Bootstrap 5 Fashion Store HTML CSS Template">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="css/vendor.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <script src="https://kit.fontawesome.com/9c46563f40.js" crossorigin="anonymous"></script>
 

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&family=Marcellus&display=swap"
    rel="stylesheet">
     <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <?php include 'connect.php'?>
<div class="noticenavi">
  Welcome to The Alley Snack and Drink
</div>
<nav class="navbar navbar-expand-lg bg-light text-uppercase fs-6 p-3 border-bottom align-items-center">
  <div class="container-fluid">
    <div class="row justify-content-between align-items-center w-100">

      <div class="col-auto">
        <a class="navbar-brand text-dark" href="home.php"
          style="font-size: 1.8rem; font-family: 'Marcellus', serif; font-weight: 400; letter-spacing: 2px;">
          The Alley
        </a>
      </div>

      <div class="col-auto">
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
          aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>

          <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 gap-1 gap-md-5 pe-3">
              <li class="nav-item dropdown">
                <a class="nav-link" href="home.php">Home</a>
                
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="snack.php">Shop</a>
                 
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="contact.php">Contact</a>
              </li>


              <li>
                <li class="nav-item">
                   <a href="product_invoice.php">
                    <button type="button" class="btn btn-primary position-relative m-2">
                      <i class="bi bi-cart"></i>
                      <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo $product_carttotal; ?>
                        <span class="visually-hidden">unread messages</span>
                      </span>
                    </button>
                  </a>
                </li>
              </li>
            </ul>
          </div>
        </div>
      </div>


    </div>

  </div>
</nav>
</body>