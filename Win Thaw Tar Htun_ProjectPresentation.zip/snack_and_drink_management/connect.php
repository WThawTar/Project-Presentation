<?php
    $host ="localhost";
    $port = 3306;
    $dbName ="ispp";
    $userName ="root";
    $password ="";

    $con= new mysqli($host,$userName,$password,$dbName);
    if($con->connect_error)
    {
        echo "Connection Error!";
    }
?>

  