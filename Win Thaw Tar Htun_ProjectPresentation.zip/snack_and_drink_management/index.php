<?php
session_start();
include("connect.php");

$error = "";

if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM admin WHERE username='$username'";
    $result = mysqli_query($con, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        if ($password == $row["password"]) {
            $_SESSION["adminid"] = $row["adminid"];
            $_SESSION["role"] = "admin";
            header("Location: admin/index.php");
            exit();
        } else {
            $error = "Incorrect password!";
        }
    }

    $query = "SELECT * FROM staff WHERE susername='$username'";
    $result = mysqli_query($con, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        if ($password == $row["spassword"]) {
            $_SESSION["staffid"] = $row["staffid"];
            $_SESSION["role"] = "staff";
            header("Location: admin/index.php");
            exit();
        } else {
            $error = "Incorrect password!";
        }
    }

    $query = "SELECT * FROM customer WHERE cusname='$username'";
    $result = mysqli_query($con, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        if ($password == $row["cuspassword"]) {
            $_SESSION["cusid"] = $row["cusid"];
            $_SESSION["role"] = "customer";
            header("Location: home.php");
            exit();
        } else {
            $error = "Incorrect password!";
        }
    }

    if ($error == "") {
        $error = "Username not found!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f7f7f7;
        }
        .login-box {
            max-width: 400px;
            margin: 80px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>

<div class="login-box">
    <h3 class="text-center mb-4">Login</h3>

    <?php if ($error != "") { ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST">

        <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <button type="submit" name="login" class="btn btn-dark w-100">Login</button>

    </form>
</div>

</body>
</html>
