<?php
session_start();
include("connect.php");

if (!isset($_SESSION["cusid"])) {
    die("Please login first.");
}

$cusid = $_SESSION["cusid"];
$cart = $_SESSION["product_cart"];
$orderdate = date("Y-m-d");

$paymenttype = isset($_POST['paymenttype']) ? $_POST['paymenttype'] : 'cash';

$deliverytypeid = isset($_POST['deliverytypeid']) ? $_POST['deliverytypeid'] : (isset($_SESSION['delivery']) ? $_SESSION['delivery'] : 1);

$totalamount = 0;
foreach ($cart as $pid => $qty) {
    $q = mysqli_query($con, "SELECT Pprice FROM product WHERE Pid='$pid'");
    $r = mysqli_fetch_assoc($q);
    $totalamount += $r['Pprice'] * $qty;
}

$df = mysqli_query($con, "SELECT deliveryfee FROM deliverytype WHERE deliverytypeid='$deliverytypeid'");
$dr = mysqli_fetch_assoc($df);
$delivery_fee = $dr['deliveryfee'];

$grandtotal = $totalamount + $delivery_fee;

mysqli_query($con, "
    INSERT INTO payment (paymentamount, paymentdate, paymenttype)
    VALUES ('$grandtotal', '$orderdate', '$paymenttype')
");
$paymentid = mysqli_insert_id($con);

mysqli_query($con, "INSERT INTO shoppingcart (cartqty) VALUES ('$grandtotal')");
$shoppingcartid = mysqli_insert_id($con);

$ordertypeid = 1; // 1 = delivery
mysqli_query($con, "
    INSERT INTO orders (shoppingcartid, cusid, paymentid, orderdate)
    VALUES ('$shoppingcartid', '$cusid', '$paymentid', '$orderdate')
");
$orderid = mysqli_insert_id($con);

mysqli_query($con, "UPDATE shoppingcart SET orderid='$orderid' WHERE shoppingcartid='$shoppingcartid'");

foreach ($cart as $pid => $qty) {
    $p = mysqli_fetch_assoc(mysqli_query($con, "SELECT Pprice FROM product WHERE Pid='$pid'"));
    $price = $p['Pprice'];
    $total = $price * $qty;

    mysqli_query($con, "
        INSERT INTO order_details (orderid, pid, qty, price, total)
        VALUES ('$orderid', '$pid', '$qty', '$price', '$total')
    ");
}

unset($_SESSION['product_cart']);
unset($_SESSION['delivery']);
unset($_SESSION['paymenttype']);

echo "<script>alert('Order Confirmed Successfully!'); location='home.php';</script>";
?>
