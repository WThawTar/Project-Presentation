<?php
include("header.php");
include("connect.php");

if (!isset($_SESSION["product_cart"])) {
    $_SESSION["product_cart"] = [];
}

if (isset($_GET['upid'])) {
    $upid = $_GET['upid'];
    $qty = $_GET['qty'];
    $_SESSION["product_cart"][$upid] = $qty;
}

if (isset($_GET['dpid'])) {
    $pid = $_GET['dpid'];
    unset($_SESSION['product_cart'][$pid]);
}

$delivery_options = []; 
$q = mysqli_query($con, "SELECT * FROM deliverytype");
while ($row = mysqli_fetch_assoc($q)) {
    $delivery_options[$row['deliverytypeid']] = [
        "name" => $row['deliverytype'],
        "fee"  => $row['deliveryfee']
    ];
}

if (isset($_GET['delivery'])) {
    $_SESSION['delivery'] = $_GET['delivery'];
}

$delivery_fee = 0;
if (isset($_SESSION['delivery']) && isset($delivery_options[$_SESSION['delivery']])) {
    $delivery_fee = $delivery_options[$_SESSION['delivery']]['fee'];
}
?>

<script>
let chgqty = (Pid, qe) => {
    location.assign('product_invoice.php?upid=' + Pid + '&qty=' + qe.value);
}
</script>

<div class="container my-5">
    <h2 class="mb-4 text-center">Invoice for the Booking</h2>

    <div class="card-body p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th width="120">Qty</th>
                        <th>Total</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 1;
                        $alltotal = 0;

                        foreach ($_SESSION["product_cart"] as $Pid => $qty) {
                            echo "<tr>";
                            echo "<td>$no</td>";
                            echo "<td><span class='badge bg-secondary'>$Pid</span></td>";

                            $sql = "SELECT Pprice, Pname FROM product WHERE Pid=$Pid";
                            $query = mysqli_query($con, $sql);

                            if ($row = mysqli_fetch_assoc($query)) {
                                $Pname = $row["Pname"];
                                $Pprice = $row["Pprice"];
                                $total = $Pprice * $qty;
                                $alltotal += $total;

                                echo "<td>$Pname</td>";
                                echo "<td>$ $Pprice</td>";
                                echo "<td>
                                        <input type='number' min='1' class='form-control text-center' 
                                        value='$qty' onchange='chgqty($Pid,this)'>
                                      </td>";
                                echo "<td class='fw-bold'>$ $total</td>";
                            }

                            echo "<td>
                                    <a href='product_invoice.php?dpid=$Pid' class='text-danger fs-5'>
                                        <i class='bi bi-trash3'></i>
                                    </a>
                                  </td>";
                            echo "</tr>";
                            $no++;
                        }
                    ?>
                </tbody>
                <tfoot>
                    <tr class="table-light">
                        <td colspan="5" class="text-end fw-bold fs-5">Subtotal:</td>
                        <td class="fw-bold fs-5">$ <?php echo $alltotal; ?></td>
                        <td></td>
                    </tr>
                    <tr class="table-light">
                        <td colspan="5" class="text-end fw-bold fs-6">Delivery Fee:</td>
                        <td class="fw-bold fs-5">$ <?php echo $delivery_fee; ?></td>
                        <td></td>
                    </tr>
                    <tr class="table-light">
                        <td colspan="5" class="text-end fw-bold fs-4">Grand Total:</td>
                        <td class="fw-bold fs-5 text-success">$ <?php echo $alltotal + $delivery_fee; ?></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <hr class="my-4">
        <h4 class="mb-3 text-primary">Choose Delivery Method</h4>
        <form method="GET" action="product_invoice.php">
            <?php foreach($delivery_options as $id => $data): ?>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="delivery" value="<?php echo $id; ?>"
                        <?php if (isset($_SESSION['delivery']) && $_SESSION['delivery'] == $id) echo 'checked'; ?>>
                    <label class="form-check-label">
                        <?php echo $data['name']; ?> 
                        (<?php echo $data['fee'] > 0 ? "+$".$data['fee'] : "Free"; ?>)
                    </label>
                </div>
            <?php endforeach; ?>
            <button class="btn btn-primary mt-3">Apply</button>
        </form>

        <hr class="my-4">
        <h4 class="mb-3 text-primary">Choose Payment Method</h4>
        <form method="POST" action="snackorderconfirm.php" id="confirmForm">
            <div class="mb-3">
                <select name="paymenttype" class="form-select w-50">
                    <option value="cash">Cash</option>
                    <option value="debit">Debit</option>
                    <option value="credit">Credit</option>
                </select>
            </div>
            <input type="hidden" name="deliverytypeid" value="<?php echo isset($_SESSION['delivery']) ? $_SESSION['delivery'] : 1; ?>">
            <button type="submit" class="btn btn-success btn-lg mt-3">✔ Confirm Order</button>
        </form>

        <div class="text-end mt-4">
            <a href="snack.php" class="btn btn-outline-primary btn-lg me-2">← Back to Snacks</a>
            <a href="snack.php?delete=all" class="btn btn-outline-danger btn-lg me-2">🗑 Cancel Order</a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
