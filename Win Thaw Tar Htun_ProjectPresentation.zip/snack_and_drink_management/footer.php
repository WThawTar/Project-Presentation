<footer class="bg-light mt-5 pt-5">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6 mb-4">
        <a href="home.php">
         
        </a>
        <p>The Alley was founded in 2013 by Mao Wei in Taiwan, created with the vision of using modern technology to offer snacks and drinks through an online service platform</p>
        <div class="d-flex gap-2 mt-2">
          <a href="https://facebook.com" class="text-secondary fs-5"><i class="bi bi-facebook"></i></a>
          <a href="https://twitter.com" class="text-secondary fs-5"><i class="bi bi-twitter"></i></a>
          <a href="https://youtube.com" class="text-secondary fs-5"><i class="bi bi-youtube"></i></a>
          <a href="https://pinterest.com" class="text-secondary fs-5"><i class="bi bi-pinterest"></i></a>
          <a href="https://instagram.com" class="text-secondary fs-5"><i class="bi bi-instagram"></i></a>
        </div>
      </div>

      <div class="col-md-3 col-sm-6 mb-4">
        <h5 class="text-uppercase mb-3">Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="home.php" class="text-decoration-none text-dark">Home</a></li>
          <li><a href="about.php" class="text-decoration-none text-dark">About</a></li>
          <li><a href="services.php" class="text-decoration-none text-dark">Services</a></li>
          <li><a href="shop.php" class="text-decoration-none text-dark">Shop</a></li>
          <li><a href="contact.php" class="text-decoration-none text-dark">Contact</a></li>
        </ul>
      </div>

      <div class="col-md-3 col-sm-6 mb-4">
        <h5 class="text-uppercase mb-3">Help & Info</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-decoration-none text-dark">Invoice</a></li>
          <li><a href="#" class="text-decoration-none text-dark">Returns & Exchanges</a></li>
          <li><a href="#" class="text-decoration-none text-dark">Shipping & Delivery</a></li>
          <li><a href="contact.php" class="text-decoration-none text-dark">Contact Us</a></li>
          <li><a href="contact.php" class="text-decoration-none text-dark">FAQs</a></li>
        </ul>
      </div>

      <div class="col-md-3 col-sm-6 mb-4">
        <h5 class="text-uppercase mb-3">Contact Us</h5>
        <p><i class="bi bi-envelope-fill me-2"></i> <a href="mailto:contact@yourcompany.com" class="text-decoration-none">contact@thealley.com</a></p>
        <p><i class="bi bi-telephone-fill me-2"></i> <a href="tel:+43720115278" class="text-decoration-none">+959765115431</a></p>
        <p><i class="bi bi-geo-alt-fill me-2"></i> 123 Main Street, Myanmar</p>
      </div>
    </div>

    <hr>

    <div class="row py-3">
      <div class="col-md-6 text-secondary">
        <small>© The Alley Snacks & Drinks. All rights reserved.</small>
      </div>
      <div class="col-md-6 text-md-end">
        <small>Designed by Win Thaw Tar Htun</small>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.js"></script>
