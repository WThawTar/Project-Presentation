<?php
include("header.php");
?>

<div class="container my-5">
    <h2 class="text-center mb-4">Contact Us</h2>

    <div class="row">
        <div class="col-md-7">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h5 class="card-title mb-3">Send us a message</h5>
                    <form action="contact_submit.php" method="POST">
                        <div class="mb-3">
                            <label for="name" class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                        </div>

                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                        </div>

                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" name="message" rows="5" placeholder="Write your message..." required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg">Send Message</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-5 mt-4 mt-md-0">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <h5 class="card-title mb-3">Contact Information</h5>
                    <p><i class="bi bi-geo-alt-fill me-2"></i>123 Main Street, California</p>
                    <p><i class="bi bi-telephone-fill me-2"></i>+445 986 647</p>
                    <p><i class="bi bi-envelope-fill me-2"></i>contact@thealley.com</p>
                    <hr>
                    <h6>Follow Us</h6>
                    <a href="#" class="me-2 text-decoration-none"><i class="bi bi-facebook fs-4"></i></a>
                    <a href="#" class="me-2 text-decoration-none"><i class="bi bi-twitter fs-4"></i></a>
                    <a href="#" class="me-2 text-decoration-none"><i class="bi bi-instagram fs-4"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>
